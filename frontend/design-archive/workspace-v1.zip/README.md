# Kata Workspace — frontend

A local-only React + TypeScript + Vite application for the project's question-and-CSV workflow. The interface uses navy blue and white, with responsive desktop and mobile layouts.

## Run

Use Node.js 26 (tested with 26.3.1) and npm. Supported alternatives for the full test toolchain are Node 22.22.2+ within the 22.x line or Node 24.15+ within the 24.x line; see the package engines constraint.

```bash
cd /Users/nuttananapirakcheewan/kataAI/frontend
npm ci
npm run dev
```

Open the localhost URL printed by Vite (normally `http://127.0.0.1:5173`). The development server is bound to loopback, not the LAN. Run `npm run build` and `npm run preview` to exercise the production bundle.

## What works

- A message textbox with required/4,000-character validation.
- CSV drag and drop or keyboard-accessible file selection.
- One UTF-8 CSV, at most 128 KiB, with a unique non-empty header and data rows.
- Structural parsing, quoted-field support, column-width checks, and invalid-encoding feedback.
- A five-row dataset preview. Values are rendered as text, never executable HTML or spreadsheet formulas.
- Built-in synthetic sample CSV and an example question (inputs only, not simulated answers).
- A real local prepared-payload inspector and Copy JSON action.
- Removing/replacing a file, editing the question, and resetting the draft invalidate the old payload.
- Asynchronous file-read generation tracking prevents superseded reads from restoring old data.

**Submit means Prepare payload.** It does not upload, call a model, generate Python, execute code, create a Job, or simulate success. No network adapter, API client, authentication mechanism, backend, persistence, or request-status polling is included.

Question, file and metadata remain in React/browser memory and are lost on reset/reload. Nothing is written to localStorage, IndexedDB or cookies. Copy JSON is an explicit exception: it writes the displayed metadata to the clipboard when the user clicks it. A clipboard-denied message explains how to copy manually.

## Payload handoff

Read [FRONTEND-PAYLOAD-HANDOFF.md](FRONTEND-PAYLOAD-HANDOFF.md). The prepared object contains `metadata` and the **original File** as `attachment`. The JSON inspector/copy action shows metadata only. It is not a complete dataset upload and must not be treated as the final API request body.

## Tests and checks

```bash
npm test
npm run build
npx playwright install chromium
npm run test:e2e -- --workers=2
```

Playwright runs desktop Chromium and a mobile-sized Chromium profile. It starts a local Vite server when needed, or reuses the running one on port 5173. Browser tests cover file selection/drop, validation, stale-payload invalidation, reset, safe text rendering, keyboard support, horizontal overflow, no fetch/XHR on preparation, and axe accessibility checks in empty/prepared states.

Actual UI screenshots are generated under `evidence/`; the HTML browser-test report is under the ignored `playwright-report/`. Automated accessibility checks are not a complete accessibility certification. Safari, Firefox, real iOS devices and backend integration are not covered by this test suite.

## Source layout

```text
src/App.tsx                 UI and local draft state
src/styles.css              Navy/white tokens, layout, responsive states
src/lib/csv.ts              Browser-only file admission and CSV inspection
src/lib/submission.ts       Typed local metadata preparation; no transport
src/lib/*.test.ts           Validation and metadata unit tests
src/App.test.tsx            Component interaction tests
e2e/workspace.spec.ts       Real-browser end-to-end/accessibility tests
```

The application's visible brand is a project label, not an official Kata Containers interface or a claim of a running sandbox. The original project specification and research guide are unchanged.

import { useRef, useState } from 'react'
import type { FormEvent } from 'react'
import {
  ArrowRight,
  ArrowUpRight,
  Braces,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Code2,
  Copy,
  FileSpreadsheet,
  FileUp,
  Layers3,
  LoaderCircle,
  LockKeyhole,
  Plus,
  RotateCcw,
  ShieldCheck,
  X,
} from 'lucide-react'
import { inspectCsv } from './lib/csv'
import type { CsvDataset } from './lib/csv'
import { MAX_QUESTION_LENGTH, prepareSubmission, validateQuestion } from './lib/submission'
import type { PreparedSubmission } from './lib/submission'

const EXAMPLE_QUESTION =
  'Which product had the largest absolute drop in sales from October to November?'
const SAMPLE_CSV =
  'product,month,units\nNotebook,October,120\nNotebook,November,80\nPen,October,50\nPen,November,45\n'

export default function App() {
  const [question, setQuestion] = useState('')
  const [dataset, setDataset] = useState<CsvDataset | null>(null)
  const [questionError, setQuestionError] = useState<string>()
  const [fileError, setFileError] = useState<string>()
  const [reading, setReading] = useState(false)
  const [dragging, setDragging] = useState(false)
  const [copyStatus, setCopyStatus] = useState('')
  const [prepared, setPrepared] = useState<PreparedSubmission | null>(null)
  const input = useRef<HTMLInputElement>(null)
  const questionInput = useRef<HTMLTextAreaElement>(null)
  const fileGeneration = useRef(0)
  const questionValid = !validateQuestion(question)

  function resetDraft() {
    ++fileGeneration.current
    setQuestion('')
    setDataset(null)
    setPrepared(null)
    setQuestionError(undefined)
    setFileError(undefined)
    setReading(false)
    setDragging(false)
    setCopyStatus('')
    if (input.current) input.current.value = ''
    questionInput.current?.focus()
  }

  async function copyPayload() {
    if (!prepared) return
    try {
      await navigator.clipboard.writeText(JSON.stringify(prepared.metadata, null, 2))
      setCopyStatus('JSON copied to clipboard.')
    } catch {
      setCopyStatus('Clipboard is unavailable. Select and copy the JSON below.')
    }
  }

  async function selectFiles(files: File[]) {
    const generation = ++fileGeneration.current
    setPrepared(null)
    setCopyStatus('')
    setDataset(null)
    setFileError(undefined)
    if (files.length !== 1) {
      setReading(false)
      setFileError('Choose one CSV at a time. Multiple files are not supported yet.')
      return
    }
    setReading(true)
    try {
      const inspected = await inspectCsv(files[0])
      if (generation === fileGeneration.current) setDataset(inspected)
    } catch (error) {
      if (generation === fileGeneration.current)
        setFileError(
          error instanceof Error
            ? error.message
            : 'This file could not be read. Please choose it again.',
        )
    } finally {
      if (generation === fileGeneration.current) setReading(false)
    }
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const error = validateQuestion(question)
    setQuestionError(error)
    if (!dataset)
      setFileError(
        reading
          ? 'Wait for your CSV to finish validating.'
          : 'Add a CSV file before preparing your payload.',
      )
    if (error) questionInput.current?.focus()
    else if (!dataset) input.current?.focus()
    if (error || !dataset || reading) return
    setCopyStatus('')
    setPrepared(prepareSubmission(question, dataset))
  }

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">
        Skip to workspace
      </a>
      <aside className="sidebar" aria-label="Workspace navigation">
        <div className="brand">
          <span className="brand-mark">
            <Layers3 size={23} strokeWidth={1.7} />
          </span>
          <span>
            kata<span className="brand-dot">.</span>
          </span>
        </div>
        <div className="sidebar-label">ANALYSIS WORKSPACE</div>
        <nav>
          <a className="nav-item active" href="#main-content" aria-current="page">
            <Plus size={18} /> New analysis <ChevronRight size={15} />
          </a>
          <a className="nav-item" href="#handoff-notes">
            <Braces size={18} /> Payload guide
          </a>
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-boundary">
            <LockKeyhole size={17} />
            <span>Local by design</span>
          </div>
          <p>Your question and file stay in this browser tab. Nothing is uploaded.</p>
          <div className="version">
            COURSE MVP <span>v0.1</span>
          </div>
        </div>
      </aside>

      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace <ChevronRight size={14} />
            <span>New analysis</span>
          </div>
          <span className="mode-badge">
            <span className="status-dot" /> Frontend only
          </span>
        </header>
        <main id="main-content" tabIndex={-1}>
          <div className="page-heading">
            <div>
              <div className="eyebrow">YOUR DATA. YOUR QUESTION.</div>
              <h1>Start with a question.</h1>
              <p>Bring a CSV. Tell us what you want to find out.</p>
            </div>
            <button className="reset-button" type="button" onClick={resetDraft}>
              <RotateCcw size={14} /> Reset draft
            </button>
          </div>
          <div className="workflow" aria-label="Preparation steps">
            <div className="workflow-step current">
              <span>01</span> Compose request
            </div>
            <div className="workflow-line" />
            <div className={`workflow-step ${prepared ? 'current' : ''}`}>
              <span>{prepared ? <Check size={13} /> : '02'}</span> Inspect payload
            </div>
            <span className="workflow-note">No execution in this preview</span>
          </div>
          <div className="workspace-grid">
            <section className="composer" aria-labelledby="compose-title">
              <div className="card-heading">
                <h2 id="compose-title">New analysis</h2>
                <span className="muted-tag">CSV WORKFLOW</span>
              </div>
              <form onSubmit={submit} noValidate>
                <div className="question-section">
                  <div className="field-heading">
                    <label htmlFor="question">
                      Your question <span className="required-label">Required</span>
                    </label>
                    <span className="field-index">01</span>
                  </div>
                  <p id="question-help" className="field-description">
                    Be specific about the calculation or comparison you need.
                  </p>
                  <div className={`textarea-wrap ${questionError ? 'invalid' : ''}`}>
                    <textarea
                      ref={questionInput}
                      id="question"
                      name="question"
                      aria-label="Your question"
                      aria-required="true"
                      value={question}
                      aria-describedby={`question-help question-count${questionError ? ' question-error' : ''}`}
                      aria-invalid={!!questionError}
                      placeholder="e.g. Which product had the biggest drop in sales last month?"
                      onChange={(event) => {
                        setQuestion(event.target.value)
                        setQuestionError(undefined)
                        setCopyStatus('')
                        setPrepared(null)
                      }}
                    />
                    <div className="textarea-footer">
                      <span>Natural language, precise questions.</span>
                      <span
                        id="question-count"
                        className={question.length > MAX_QUESTION_LENGTH ? 'over-limit' : ''}
                      >
                        {question.length.toLocaleString('en-US')} / 4,000
                      </span>
                    </div>
                  </div>
                  {questionError && (
                    <p id="question-error" className="field-error" role="alert">
                      {questionError}
                    </p>
                  )}
                  <button
                    type="button"
                    className="text-button example-question"
                    onClick={() => {
                      setQuestion(EXAMPLE_QUESTION)
                      setQuestionError(undefined)
                      setCopyStatus('')
                      setPrepared(null)
                      questionInput.current?.focus()
                    }}
                  >
                    Try an example question <ArrowUpRight size={14} />
                  </button>
                </div>
                <div className="dataset-section">
                  <div className="field-heading">
                    <label htmlFor="csv-file">
                      Your dataset <span className="required-label">Required</span>
                    </label>
                    <span className="field-index">02</span>
                  </div>
                  <p id="file-help" className="field-description">
                    One UTF-8, comma-separated CSV with a header row. Up to 128 KiB.
                  </p>
                  <div
                    className={`dropzone ${dragging ? 'dragging' : ''} ${fileError ? 'invalid' : ''} ${dataset ? 'has-file' : ''}`}
                    onDragOver={(event) => {
                      event.preventDefault()
                      setDragging(true)
                    }}
                    onDragLeave={(event) => {
                      if (!event.currentTarget.contains(event.relatedTarget as Node | null))
                        setDragging(false)
                    }}
                    onDrop={(event) => {
                      event.preventDefault()
                      setDragging(false)
                      void selectFiles(Array.from(event.dataTransfer.files))
                      if (input.current) input.current.value = ''
                    }}
                  >
                    <input
                      ref={input}
                      className="file-input"
                      type="file"
                      id="csv-file"
                      aria-label="Choose CSV file"
                      aria-required="true"
                      accept=".csv,text/csv"
                      aria-describedby={`file-help${fileError ? ' file-error' : ''}`}
                      aria-invalid={!!fileError}
                      onChange={(event) => {
                        if (event.target.files?.length)
                          void selectFiles(Array.from(event.target.files))
                        event.target.value = ''
                      }}
                    />
                    {reading ? (
                      <div className="drop-empty" role="status">
                        <LoaderCircle className="spin" size={30} />
                        <strong>Checking your CSV…</strong>
                        <span>Validating structure locally</span>
                      </div>
                    ) : dataset ? (
                      <div className="selected-file">
                        <div className="file-icon">
                          <FileSpreadsheet size={23} />
                        </div>
                        <div className="file-info">
                          <strong>{dataset.file.name}</strong>
                          <span>
                            {(dataset.file.size / 1024).toFixed(1)} KiB{' '}
                            <span aria-hidden="true">·</span>{' '}
                            {dataset.rowCount.toLocaleString('en-US')} rows{' '}
                            <span aria-hidden="true">·</span> {dataset.headers.length} columns
                          </span>
                          <span className="valid-file">
                            <CheckCircle2 size={13} /> CSV structure validated
                          </span>
                        </div>
                        <button
                          type="button"
                          className="icon-button remove-file"
                          aria-label="Remove file"
                          onClick={() => {
                            ++fileGeneration.current
                            setDataset(null)
                            setPrepared(null)
                            setFileError(undefined)
                          }}
                        >
                          <X size={18} />
                        </button>
                      </div>
                    ) : (
                      <div className="drop-empty">
                        <span className="upload-mark">
                          <FileUp size={27} strokeWidth={1.5} />
                        </span>
                        <strong>Drop your CSV here</strong>
                        <span>
                          or{' '}
                          <button
                            type="button"
                            className="inline-button"
                            onClick={() => input.current?.click()}
                          >
                            browse files
                          </button>{' '}
                          from your computer
                        </span>
                      </div>
                    )}
                  </div>
                  {fileError && (
                    <p className="field-error" id="file-error" role="alert">
                      {fileError}
                    </p>
                  )}
                  <div className="file-helpers">
                    <span>
                      <LockKeyhole size={13} /> Local validation only
                    </span>
                    <button
                      type="button"
                      className="text-button"
                      onClick={() => {
                        void selectFiles([
                          new File([SAMPLE_CSV], 'sample-sales.csv', { type: 'text/csv' }),
                        ])
                      }}
                    >
                      Use sample CSV <ArrowUpRight size={13} />
                    </button>
                  </div>
                  {dataset && (
                    <details className="csv-preview">
                      <summary>
                        Preview dataset <span>First {Math.min(dataset.rowCount, 5)} rows</span>
                      </summary>
                      <div
                        className="table-scroll"
                        tabIndex={0}
                        role="region"
                        aria-label="CSV preview"
                      >
                        <table>
                          <thead>
                            <tr>
                              {dataset.headers.map((header, index) => (
                                <th key={index} scope="col">
                                  {header}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {dataset.preview.map((row, index) => (
                              <tr key={index}>
                                {row.map((cell, cellIndex) => (
                                  <td key={cellIndex}>{cell}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p>Preview only. The original file is kept unchanged.</p>
                    </details>
                  )}
                </div>
                <div className="submit-row">
                  <span>
                    <ShieldCheck size={16} /> Nothing leaves your browser.
                  </span>
                  <button type="submit" className="primary-button" disabled={reading}>
                    Prepare payload <ArrowRight size={17} />
                  </button>
                </div>
              </form>
            </section>
            <aside className="inspector" aria-label="Payload inspector">
              <section
                className={`payload-card ${prepared ? 'is-prepared' : ''}`}
                aria-labelledby="payload-title"
              >
                <div className="payload-top">
                  <span>
                    <Braces size={17} /> REQUEST INSPECTOR
                  </span>
                  <span className="draft-badge">{prepared ? 'PREPARED' : 'DRAFT'}</span>
                </div>
                {prepared ? (
                  <>
                    <div className="payload-content prepared-heading" role="status">
                      <span className="payload-symbol">
                        <Check size={24} />
                      </span>
                      <h2 id="payload-title">Payload prepared</h2>
                      <p>Not sent. No backend is connected.</p>
                    </div>
                    <div className="code-heading">
                      <span>metadata.json</span>
                      <button
                        type="button"
                        className="copy-button"
                        onClick={() => void copyPayload()}
                      >
                        <Copy size={12} /> Copy JSON
                      </button>
                    </div>
                    {copyStatus && (
                      <p className="copy-status" role="status">
                        {copyStatus}
                      </p>
                    )}
                    <pre
                      data-testid="payload-json"
                      className="payload-json"
                      tabIndex={0}
                      aria-label="Prepared payload JSON"
                    >
                      {JSON.stringify(prepared.metadata, null, 2)}
                    </pre>
                    <div className="attachment-note">
                      <FileSpreadsheet size={15} />
                      <span>
                        Original CSV attached in memory.
                        <br />
                        File bytes are not included in this JSON.
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="payload-content">
                      <span className="payload-symbol">
                        <Code2 size={25} strokeWidth={1.5} />
                      </span>
                      <h2 id="payload-title">A clean handoff.</h2>
                      <p>
                        Your question and dataset, packaged for the next step. No execution, no
                        guesswork.
                      </p>
                    </div>
                    <div className="readiness">
                      <div>
                        <span className={questionValid ? 'check-dot ready' : 'check-dot'}>
                          {questionValid && <Check size={12} />}
                        </span>
                        <span>Question added</span>
                        <span>{questionValid ? 'Ready' : 'Required'}</span>
                      </div>
                      <div>
                        <span className={dataset ? 'check-dot ready' : 'check-dot'}>
                          {dataset && <Check size={12} />}
                        </span>
                        <span>CSV validated</span>
                        <span>{dataset ? 'Ready' : 'Required'}</span>
                      </div>
                    </div>
                    <div className="payload-empty-note">
                      <Braces size={14} /> Your prepared payload will appear here.
                    </div>
                  </>
                )}
              </section>
              <section className="handoff-notes" id="handoff-notes">
                <div className="small-heading">
                  <span>THE NEXT STEP, EXPLAINED</span>
                  <CircleHelp size={15} />
                </div>
                <ol>
                  <li>
                    <span>1</span>
                    <div>
                      <strong>Validate locally</strong>
                      <p>Check your question and CSV structure in this browser.</p>
                    </div>
                  </li>
                  <li>
                    <span>2</span>
                    <div>
                      <strong>Inspect the payload</strong>
                      <p>Review the exact metadata and attached file before integration.</p>
                    </div>
                  </li>
                  <li className="future-step">
                    <span>3</span>
                    <div>
                      <strong>
                        Connect a backend <small>LATER</small>
                      </strong>
                      <p>Authentication, model calls and Kata execution belong on the server.</p>
                    </div>
                  </li>
                </ol>
              </section>
            </aside>
          </div>
          <footer className="workspace-footer">
            <span>
              <LockKeyhole size={13} /> No uploads. No model calls. No code execution.
            </span>
            <span>Built for the sandboxed analysis MVP.</span>
          </footer>
        </main>
      </div>
    </div>
  )
}

import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it } from 'vitest'
import App from './App'
describe('local analysis workspace', () => {
  it('can copy a prepared payload and reset all draft data', async () => {
    const user = userEvent.setup()
    render(<App />)
    await user.click(screen.getByRole('button', { name: 'Try an example question' }))
    await user.click(screen.getByRole('button', { name: 'Use sample CSV' }))
    await screen.findByText('sample-sales.csv')
    await user.click(screen.getByRole('button', { name: 'Prepare payload' }))
    await user.click(screen.getByRole('button', { name: 'Copy JSON' }))
    expect(JSON.parse(await navigator.clipboard.readText()).question).toContain(
      'largest absolute drop',
    )
    await user.click(screen.getByRole('button', { name: 'Reset draft' }))
    expect(screen.getByLabelText('Your question')).toHaveValue('')
    expect(screen.queryByTestId('payload-json')).not.toBeInTheDocument()
    expect(screen.queryByText('sample-sales.csv')).not.toBeInTheDocument()
  })
  it('prepares real question/file metadata without displaying a fake answer', async () => {
    const user = userEvent.setup()
    render(<App />)
    expect(screen.getByText('Frontend only')).toBeInTheDocument()
    await user.type(screen.getByLabelText('Your question'), 'Which product fell most?')
    await user.upload(
      screen.getByLabelText('Choose CSV file'),
      new File(['product,units\nPen,45'], 'sales.csv', { type: 'text/csv' }),
    )
    await screen.findByText('sales.csv')
    await user.click(screen.getByRole('button', { name: 'Prepare payload' }))
    expect(await screen.findByRole('heading', { name: 'Payload prepared' })).toBeInTheDocument()
    expect(screen.getByTestId('payload-json')).toHaveTextContent('Which product fell most?')
    expect(screen.getByTestId('payload-json')).toHaveTextContent('client_request_id')
    expect(screen.getByText('Not sent. No backend is connected.')).toBeInTheDocument()
  })
})
